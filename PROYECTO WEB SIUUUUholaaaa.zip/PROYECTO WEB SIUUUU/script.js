// script.js

document.addEventListener("DOMContentLoaded", function() {
    // Obtener todos los enlaces de navegación
    var navLinks = document.querySelectorAll("nav ul li a");

    // Agregar un evento clic a cada enlace de navegación
    navLinks.forEach(function(link) {
        link.addEventListener("click", function(event) {
            // Prevenir el comportamiento predeterminado del enlace
            event.preventDefault();

            // Obtener el destino del enlace
            var targetId = link.getAttribute("href").substring(1);
            var targetSection = document.getElementById(targetId);

            // Desplazamiento suave hacia el destino
            window.scrollTo({
                top: targetSection.offsetTop,
                behavior: "smooth"
            });
        });
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Obtener todos los enlaces de navegación
    var navLinks = document.querySelectorAll("nav ul li a");

    // Agregar un evento clic a cada enlace de navegación
    navLinks.forEach(function(link) {
        link.addEventListener("click", function(event) {
            // Prevenir el comportamiento predeterminado del enlace
            event.preventDefault();

            // Obtener el destino del enlace
            var targetId = link.getAttribute("href").substring(1);
            var targetSection = document.getElementById(targetId);

            // Desplazamiento suave hacia el destino
            window.scrollTo({
                top: targetSection.offsetTop,
                behavior: "smooth"
            });

            // Agregar clase de animación a la sección de destino
            targetSection.classList.add("animate");
        });
    });
});
 document.querySelector('.content').style.margin = '50px'; 
<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}

document.getElementById("enlace1").addEventListener("click", function(event) {
  event.preventDefault(); // Evita que el enlace se comporte como un enlace normal
  window.location.href = "https://ejemplosdeia.html";
});

document.getElementById("enlace2").addEventListener("click", function(event) {
  event.preventDefault(); // Evita que el enlace se comporte como un enlace normal
  window.location.href = "https://historiadelasias.html";
});
 // script.js
document.addEventListener("DOMContentLoaded", function() {
    window.addEventListener("scroll", revealElements);

    function revealElements() {
        var reveals = document.querySelectorAll(".reveal");

        for (var i = 0; i < reveals.length; i++) {
            var windowHeight = window.innerHeight;
            var elementTop = reveals[i].getBoundingClientRect().top;
            var elementVisible = 150;

            if (elementTop < windowHeight - elementVisible) {
                reveals[i].classList.add("active");
            } else {
                reveals[i].classList.remove("active");
            }
        }
    }
});

